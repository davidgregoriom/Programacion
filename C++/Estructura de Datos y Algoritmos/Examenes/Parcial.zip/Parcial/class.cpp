#include "class.h"

class::class()
{

}
