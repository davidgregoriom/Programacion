#ifndef CLASS_H
#define CLASS_H


class class
{
public:
    class();
};

#endif // CLASS_H