#include "elementoslistadoble.h"

ElementListaDoble::ElementListaDoble(const Persona& dato):dato{dato}{}
