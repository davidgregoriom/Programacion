#pragma once

#include <string>
#include <vector>
#include "queue.h"

Queue police_raid(Queue joy_slava, const std::vector<std::string>& dnis);


