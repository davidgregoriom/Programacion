#include "wardrovelement.h"

WardrobeElement::WardrobeElement(const std::string &owner): owner{owner}{

}
