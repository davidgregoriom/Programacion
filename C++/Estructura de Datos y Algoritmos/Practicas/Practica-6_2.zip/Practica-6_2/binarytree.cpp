#include "binarytree.h"

void BinaryTree::bfs(std::function<void ( TipoDato &)> action) const
{
    Queue Q;
    Q.push(root);
    while(!Q.empty()){
        QueueTipodato e=Q.front();
        Q.pop();
        action(e->dato);
        for(auto child:e->children){
            Q.push(QueueTipodato{child});
        }
    }
}
