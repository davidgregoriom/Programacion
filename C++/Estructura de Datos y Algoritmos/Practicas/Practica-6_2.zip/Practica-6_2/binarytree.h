#ifndef BINARYTREE_H
#define BINARYTREE_H
#pragma once

#include "collections.h"
#include <memory>
#include <functional>



class ElementoArbolBinario {
    public:
        // Members
        TipoDato dato;
        std::shared_ptr<ElementoArbolBinario> left = nullptr;
        std::shared_ptr<ElementoArbolBinario> right = nullptr;
    public:
        // Constructor
        ElementoArbolBinario(const TipoDato& dato_) : dato{dato_} {}
};


class BinaryTree {
    protected:
        std::shared_ptr<ElementoArbolBinario> root = nullptr;

    public:
        BinaryTree(const TipoDato& dato);  // Creates a tree with a value

        // Breadth first search (recorrido en anchura)
        void bfs(std::function<void (TipoDato&)> action) const;
};

#endif // BINARYTREE_H
