#ifndef COLLECTIONS_H
#define COLLECTIONS_H
#pragma once

#include <memory>
#include "binarytree.h"
using namespace std;

struct TipoDato{ string dato;};

class ElementListaSimple {
    public:
        // Members
        TipoDato dato;
        std::shared_ptr<ElementListaSimple> next = nullptr;
    public:
        // Constructor
        ElementListaSimple(const TipoDato& dato_) : dato{dato_} {}
};


// Una lista simple enlazada
class LinkedList {
    public:
        LinkedList();

        void push_back(const TipoDato& dato);

    protected:
        std::shared_ptr<ElementListaSimple> front = nullptr;
};


// Una pila
class Stack {
    public:
        Stack();

        int size() const;
        bool empty() const;

        void push(const TipoDato& dato);
        void pop() const;
        TipoDato& top() const;
    protected:
        std::shared_ptr<ElementListaSimple> front = nullptr;
};


// Una cola
class Queue {
    public:
        Queue();

        int size() const;
        bool empty() const;

        TipoDato& front() const;
        TipoDato& back() const;

        void push(const TipoDato& dato);
        void pop();
    protected:
        std::shared_ptr<ElementListaSimple> _front = nullptr;
        std::shared_ptr<ElementListaSimple> _back = nullptr;
};

#endif // COLLECTIONS_H
