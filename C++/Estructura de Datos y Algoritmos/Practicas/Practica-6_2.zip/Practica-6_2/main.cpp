#include <iostream>
#include "binarytree.h"
#include "collections.h"
using namespace std;


int main() {
    /*BinaryTree tree;
    LinkedList list;

    tree.bfs( /* your lambda here */ //);
    //Now the `list` contains all the nodes from the tree in BFS order

}

