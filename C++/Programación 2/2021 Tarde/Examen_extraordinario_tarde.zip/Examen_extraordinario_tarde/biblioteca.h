

#ifndef BIBLIOTECA_H
#define BIBLIOTECA_H

#include <iostream>
#include <vector>
#include <memory>
#include "publicacion.h"
#include "libro.h"
#include "articulo.h"


using namespace std;

class Biblioteca{
private:
    vector<shared_ptr<Publicacion>>biblio;
public:
    void anadir(const shared_ptr<Articulo> & b){
        biblio.push_back(b);
    }
    void anadir(const shared_ptr<Libro> & b){
        biblio.push_back(b);
    }
    void borrar(const string &titulo,const string & autor){
        for(int i{0};i<biblio.size();i++){
            if(biblio.at(i)->getTitulo()==titulo && biblio.at(i)->getAutor()==autor){
                biblio.erase(biblio.begin()+i);
            }
        }
    }
    shared_ptr<Publicacion> buscar(const string & titulo,const string & autor){
        for(int i=0;i<biblio.size();i++){
            if(biblio.at(i)->getTitulo()==titulo && biblio.at(i)->getAutor()==autor){
                return biblio.at(i);
            }else{
                cout << "no esta";
            }
        }
        if(biblio.size()==0){
            cout<<"agenda vacia";
        }
    }
    void listar(const string &titulo,const string &autor){
        /*  if(){


        }
        */
    }
    vector<shared_ptr<Publicacion> > getBiblio() const{
        return biblio;
    }
};
ostream & operator <<(ostream & os, Biblioteca&b){
    for(auto elem:b.getBiblio()){
        os<<*elem<<endl;
    }
    if(b.getBiblio().size()==0){
        os<<"biblioteca vacia"<<endl;
    }
    return os;
}

ostream & operator <<(ostream & os,const shared_ptr<Publicacion>&b){
    os<<b->getAutor()<<endl;
    os<<b->getTitulo()<<endl;
    shared_ptr<Libro>aux1=static_pointer_cast<Libro>(b);
    shared_ptr<Articulo>aux2=static_pointer_cast<Articulo>(b);
    if(b->getAutor()==aux1->getAutor()){
        if(aux1!=nullptr){
            os<<aux1->getEditorial()<<endl;
        }
    }else if(b->getAutor()==aux2->getAutor()){
        if(aux2!=nullptr){
            os<<aux2->getOtros_autores()<<endl;
        }
    }
}

#endif // BIBLIOTECA_H
