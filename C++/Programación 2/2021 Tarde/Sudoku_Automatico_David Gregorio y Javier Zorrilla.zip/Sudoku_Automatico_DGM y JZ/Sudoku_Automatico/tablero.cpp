#include "tablero.h"

Tablero::Tablero(array<array<int, 9>,9> datos):datos{datos}{}

Tablero::Tablero(){}

